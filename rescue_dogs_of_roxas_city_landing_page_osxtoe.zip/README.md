# Rescue Dogs of Roxas City Landing Page

A beautiful, responsive landing page for Rescue Dogs of Roxas City - an animal rescue organization in Capiz, Philippines.

## Features

- 🎨 Beautiful design with custom color palette
- 📱 Fully responsive for desktop and mobile
- 📖 Single-section scroll layout
- 📘 Integrated Facebook feed
- 🐾 Animal rescue-focused content
- ⚡ Fast and SEO-optimized

## Tech Stack

- React 18
- TypeScript
- Tailwind CSS
- Vite
- Lucide React icons

## Deployment

This site is configured for automatic deployment to Netlify via GitHub.

### Netlify Setup

1. Connect your GitHub repository to Netlify
2. Set build command: `npm run build`
3. Set publish directory: `dist`
4. Add environment variables if needed

### Manual Deployment

```bash
npm install
npm run build
```

The built files will be in the `dist` directory.

## Local Development

```bash
npm install
npm run dev
```

Visit http://localhost:5173 to view the site.

## License

MIT License - feel free to use this template for your animal rescue organization!
