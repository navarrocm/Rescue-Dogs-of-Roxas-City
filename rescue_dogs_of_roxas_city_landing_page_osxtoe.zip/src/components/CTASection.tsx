import React from 'react';
import { Home, HeartHandshake, Gift, Star } from 'lucide-react';

const CTASection: React.FC = () => {
  return (
    <section className="bg-cream section-padding">
      <div className="max-w-6xl mx-auto">
        {/* Adopt Section */}
        <div className="bg-white rounded-2xl p-8 shadow-xl mb-12">
          <div className="flex items-center mb-6">
            <Home className="w-8 h-8 text-teal mr-4" />
            <h3 className="text-2xl font-bold text-brown">ADOPT</h3>
          </div>
          
          <p className="text-lg text-gray-800 mb-4 italic">
            "Indi mag bakal bag-o. Adopt."
          </p>
          
          <p className="text-lg text-gray-700 mb-6">
            Every animal adopted creates space to save another.
          </p>
          
          <p className="text-lg text-gray-700 mb-6">
            Message us → Welcome your new family member
          </p>
          
          <div className="bg-salmon-light rounded-lg p-6 text-center">
            <p className="text-xl font-semibold text-white">
              "You don't adopt pets - they adopt you. That's #privilege!"
            </p>
          </div>
        </div>

        {/* Donate Section */}
        <div className="bg-white rounded-2xl p-8 shadow-xl mb-12">
          <div className="flex items-center mb-6">
            <HeartHandshake className="w-8 h-8 text-salmon mr-4" />
            <h3 className="text-2xl font-bold text-brown">DONATE FROM AFAR VIA GCASH</h3>
          </div>
          
          <div className="bg-teal text-white rounded-lg p-6 text-center mb-6">
            <p className="text-2xl font-bold mb-2">09988896554</p>
            <p className="text-lg">Every donation goes to food, de-ticking, vaccinations, and fixing.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-cream rounded-lg">
              <p className="text-2xl font-bold text-teal">50+</p>
              <p className="text-brown">Animals Rescued</p>
            </div>
            <div className="text-center p-4 bg-cream rounded-lg">
              <p className="text-2xl font-bold text-teal">30+</p>
              <p className="text-brown">Adopted</p>
            </div>
            <div className="text-center p-4 bg-cream rounded-lg">
              <p className="text-2xl font-bold text-teal">200kg+</p>
              <p className="text-brown">Food Monthly</p>
            </div>
          </div>
          
          <div className="bg-brown text-white rounded-lg p-6">
            <p className="text-lg">
              You can get pissed drunk at <a href='https://www.facebook.com/profile.php?id=100088394887242' target='_blank' rel='noopener noreferrer' className='text-salmon-light hover:underline'>Yudi Brewing Co</a> & go about your life. You can donate to the shelter. Or you can do both and know you've helped out a local tax-paying business and a non-profit organisation 🐾.
            </p>
          </div>
        </div>

        {/* Volunteer Section */}
        <div className="bg-white rounded-2xl p-8 shadow-xl mb-12">
          <div className="flex items-center mb-6">
            <Gift className="w-8 h-8 text-teal mr-4" />
            <h3 className="text-2xl font-bold text-brown">VOLUNTEER</h3>
          </div>
          
          <p className="text-lg text-gray-800 mb-4 italic">
            "Time is a gift. Give it."
          </p>
          
          <p className="text-lg text-gray-700 mb-6">
            Walk dogs, pick up poop, assist in feeding. Your hands and hearts are needed!
          </p>
          
          <div className="text-center">
            <a 
              href="https://www.facebook.com/rescuedogsroxascity" 
              target="_blank" 
              rel="noopener noreferrer"
              className="btn-secondary inline-flex items-center"
            >
              Message us on Facebook for volunteer opportunities!
            </a>
          </div>
        </div>

        {/* Responsible Ownership Section */}
        <div className="bg-white rounded-2xl p-8 shadow-xl">
          <div className="flex items-center mb-6">
            <Star className="w-8 h-8 text-salmon mr-4" />
            <h3 className="text-2xl font-bold text-brown">BE BETTER HOOMANS.</h3>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-4 bg-cream rounded-lg">
              <p className="font-semibold text-teal">Reform Hearts & Minds</p>
            </div>
            <div className="text-center p-4 bg-cream rounded-lg">
              <p className="font-semibold text-teal">Vet visits</p>
            </div>
            <div className="text-center p-4 bg-cream rounded-lg">
              <p className="font-semibold text-teal">Spay/neuter</p>
            </div>
            <div className="text-center p-4 bg-cream rounded-lg">
              <p className="font-semibold text-teal">Love</p>
            </div>
          </div>
          
          <div className="bg-salmon-light text-white rounded-lg p-6">
            <p className="text-lg">
              Better than dating: pets don't care how much bitcoin you have in your crypto account, how many kilos you can squat at <a href='https://www.facebook.com/profile.php?id=61555972840245' target='_blank' rel='noopener noreferrer' className='text-teal-dark hover:underline'>Onfit Wellness Club</a>, what kind of electric vehicle you drive, or how rad your skydive hobby is. They're just happy to be with you!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
