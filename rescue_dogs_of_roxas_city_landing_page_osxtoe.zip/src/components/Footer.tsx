import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brown text-white section-padding">
      <div className="max-w-6xl mx-auto text-center">
        <p className="text-xl mb-4">
          Every life matters. Every being deserves a home <span className="text-watermelon">🍉</span>.
        </p>
        
        <div className="flex flex-wrap justify-center gap-3 mb-6">
          {[
            '#RescueDogsRoxasCity',
            '#AdoptDontShop',
            '#AnimalRescue',
            '#CapizPets',
            '#RoxasCity',
            '#PhilippineAnimalWelfare',
            '#DogLovers',
            '#CatLovers',
            '#PetAdoption',
            '#AnimalShelter'
          ].map((tag, index) => (
            <span key={index} className="text-salmon-light text-sm">
              {tag}
            </span>
          ))}
        </div>
        
        <p className="text-cream">
          © 2021-2022 Rescue Dogs of Roxas City
        </p>
      </div>
    </footer>
  );
};

export default Footer;
