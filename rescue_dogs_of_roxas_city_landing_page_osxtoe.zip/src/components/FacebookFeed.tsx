import React from 'react';

const FacebookFeed: React.FC = () => {
  return (
    <section className="bg-white section-padding">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-teal mb-4">Follow Our Journey</h2>
          <p className="text-lg text-gray-600">
            Stay updated with our latest rescues, adoptions, and shelter life
          </p>
        </div>
        
        {/* Facebook Page Plugin */}
        <div className="fb-page" 
             data-href="https://www.facebook.com/rescuedogsroxascity"
             data-tabs="timeline"
             data-width="100%"
             data-height="800"
             data-small-header="false"
             data-adapt-container-width="true"
             data-hide-cover="false"
             data-show-facepile="true">
        </div>

        <div className="text-center mt-8">
          <a 
            href="https://www.facebook.com/rescuedogsroxascity" 
            target="_blank" 
            rel="noopener noreferrer"
            className="btn-primary inline-flex items-center"
          >
            Follow us on Facebook for daily updates →
          </a>
        </div>
      </div>
    </section>
  );
};

export default FacebookFeed;
