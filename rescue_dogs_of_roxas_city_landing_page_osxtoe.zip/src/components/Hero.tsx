import React from 'react';
import { Heart, Users, PawPrint } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="bg-gradient-to-br from-salmon-light to-cream section-padding">
      <div className="max-w-6xl mx-auto text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-white p-4 rounded-full shadow-lg">
            <PawPrint className="w-12 h-12 text-salmon" />
          </div>
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold text-brown mb-6 leading-tight">
          Rescue Dogs of Roxas City
        </h1>
        
        <div className="bg-white rounded-2xl p-8 shadow-xl mb-8">
          <p className="text-lg md:text-xl text-gray-800 mb-4 leading-relaxed">
            <strong className="text-salmon text-2xl">Rescue Dogs of Roxas City</strong> is a dedicated group of volunteers committed to saving abused, neglected, and abandoned pets, as well as stray cats and dogs. Please consider donating and/or volunteering.
          </p>
          
          <p className="text-lg md:text-xl text-gray-800 leading-relaxed">
            These lovable companions are ready to adopt their own responsible 'hoomans.' That could be you 😂
          </p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 mt-8">
          <div className="flex items-center bg-white rounded-lg p-4 shadow-md">
            <Heart className="w-6 h-6 text-salmon mr-2" />
            <span className="text-brown font-semibold">50+ Animals Rescued</span>
          </div>
          <div className="flex items-center bg-white rounded-lg p-4 shadow-md">
            <Users className="w-6 h-6 text-teal mr-2" />
            <span className="text-brown font-semibold">30+ Adopted</span>
          </div>
          <div className="flex items-center bg-white rounded-lg p-4 shadow-md">
            <PawPrint className="w-6 h-6 text-brown mr-2" />
            <span className="text-brown font-semibold">200kg+ Food Monthly</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
