import React, { useEffect } from 'react';
import Hero from './components/Hero';
import FacebookFeed from './components/FacebookFeed';
import CTASection from './components/CTASection';
import Footer from './components/Footer';

function App() {
  useEffect(() => {
    // Load Facebook SDK
    const loadFacebookSDK = () => {
      if (window.FB) return;
      
      const script = document.createElement('script');
      script.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v18.0';
      script.async = true;
      script.defer = true;
      script.crossOrigin = 'anonymous';
      document.body.appendChild(script);
    };

    loadFacebookSDK();
  }, []);

  return (
    <div className="min-h-screen bg-cream">
      <Hero />
      <FacebookFeed />
      <CTASection />
      <Footer />
    </div>
  );
}

export default App;
