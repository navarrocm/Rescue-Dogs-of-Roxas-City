/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        salmon: {
          DEFAULT: '#E8847A',
          light: '#F7A99A'
        },
        teal: {
          DEFAULT: '#5C9E9E',
          dark: '#4A8C8C'
        },
        brown: {
          DEFAULT: '#8C6E5A',
          light: '#A67B6B'
        },
        cream: {
          DEFAULT: '#FDF8F2',
          light: '#FFFBF5'
        },
        watermelon: '#E65C5C'
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
